# J.A.R.V.I.S – AI Desktop Assistant 🤖

A Python-powered AI assistant that listens to your voice, processes commands using OpenAI, and responds naturally.

## Features
- Voice input via microphone
- AI responses via OpenAI
- Text-to-Speech output
- Extendable command system

## Installation
```bash
git clone https://github.com/RupaliBaiyyaTribhuvan/AI-Desktop-Assistant-JARVIS.git
cd AI-Desktop-Assistant-JARVIS
pip install -r requirements.txt
cp configs/config.example.json configs/config.json
```

## Usage
```bash
python jarvis.py
```

### Credits
Based on [YouTube JARVIS Tutorial](https://www.youtube.com/watch?v=s_8b5iq4Rvk), refined and modularized.

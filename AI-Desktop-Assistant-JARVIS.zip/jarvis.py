""" 
Main script for J.A.R.V.I.S – AI Desktop Assistant 
Integrates OpenAI API, SpeechRecognition, and Text-to-Speech (TTS).
"""

import openai
import speech_recognition as sr
import pyttsx3
import json
import os

# Load API Key
with open("configs/config.json") as f:
    config = json.load(f)
openai.api_key = config.get("OPENAI_API_KEY")

engine = pyttsx3.init()

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        audio = r.listen(source)
    try:
        query = r.recognize_google(audio, language="en-in")
        return query
    except Exception as e:
        return ""

def process_query(query):
    if query:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=query,
            max_tokens=150
        )
        answer = response.choices[0].text.strip()
        return answer
    return "I didn't catch that."

if __name__ == "__main__":
    speak("Hello, I am Jarvis. How can I assist you today?")
    while True:
        command = listen()
        if "exit" in command.lower():
            speak("Goodbye!")
            break
        response = process_query(command)
        print("Jarvis:", response)
        speak(response)

import unittest
from utils.command_utils import handle_command

class TestCommands(unittest.TestCase):
    def test_google_command(self):
        self.assertEqual(handle_command("open google"), "Opening Google...")

if __name__ == "__main__":
    unittest.main()

""" Command handling functions for JARVIS """

def handle_command(command: str) -> str:
    if "open google" in command.lower():
        return "Opening Google..."
    return "Command not recognized."
